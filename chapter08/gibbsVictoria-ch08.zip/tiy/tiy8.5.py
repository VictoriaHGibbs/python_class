def describe_city(city, country="US"):
    """Prints a simple sentence"""
    print(f"{city.title()} is in {country.upper()}")

describe_city("asheville")
describe_city("charlotte")
describe_city("reykjavik")
