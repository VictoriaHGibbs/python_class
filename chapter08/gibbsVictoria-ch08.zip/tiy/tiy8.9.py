def show_messages(messages):
    """Prints a list"""
    for message in messages:
        print(f"{message}")

messages = ['Hey are you busy?', 'Want to grab lunch?', 'Can I call you?']

show_messages(messages)
