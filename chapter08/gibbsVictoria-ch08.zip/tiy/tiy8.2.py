def favorite_book(title):
    """Prints the favorite book."""
    print(f"One of my favorite books is {title.title()}!")

favorite_book("lord of the rings")
