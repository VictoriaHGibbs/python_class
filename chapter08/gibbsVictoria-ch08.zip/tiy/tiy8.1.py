def display_message():
    """Tells everyone what we are learning."""
    print(f"We are learning about functions in this chapter! :D")

display_message()
