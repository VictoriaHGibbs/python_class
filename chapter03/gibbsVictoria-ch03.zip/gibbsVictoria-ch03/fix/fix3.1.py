# fix3.1.py
# This is a list of the original six hockey teams in the NHL.
# This program is supposed to print out the list but there is an error in the code
# Fix the error so the list prints all six teams.

original_six = ['Detroit Red Wings', 'Chicago Black Hawks', 'Toronto Maple Leafs', 'Montreal Canadians', 'Boston Bruins', 'New York Rangers'],
print(original_six)
