# fix3.1.py
# This is a list of the original six hockey teams in the NHL.
# This program is supposed to print out the teams in alphabetical order but it 
# prints the teams in their original order instead.
# What can you do to fix the program so it prints the teams in alpha order?

original_six = ['Detroit Red Wings', 'Chicago Black Hawks', 'Toronto Maple Leafs', 'Montreal Canadians', 'Boston Bruins', 'New York Rangers']
original_six.sort()
print(original_six)


