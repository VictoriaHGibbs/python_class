names = ['zach', 'becca', 'damiana', 'shanice']

print(f"Hello {names[0]}, how are you?")
print(f"Hello {names[1]}, how are you?")
print(f"Hello {names[2]}, how are you?")
print(f"Hello {names[3]}, how are you?")


