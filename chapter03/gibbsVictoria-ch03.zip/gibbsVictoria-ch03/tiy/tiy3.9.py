guest = ['grandma ann', 'becca', 'damiana']

print(len(guest))
