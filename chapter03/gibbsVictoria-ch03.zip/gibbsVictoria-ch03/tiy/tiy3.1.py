names = ['zach', 'becca', 'damiana', 'shanice']

print(names[0])
print(names[1])
print(names[2])
print(names[3])
