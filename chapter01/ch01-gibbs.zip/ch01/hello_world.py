print("Hello, world!")
