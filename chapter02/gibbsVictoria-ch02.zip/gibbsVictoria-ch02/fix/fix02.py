# fix02.py
# This print statement displays the word 'message' but it 
# should print the actual message instead.
# What can you do to fix this problem?

message = "Learning Python is a lot of fun, but first you will learn some of the syntax fundamentals."
print (message)
