# fix03.py
# There are two lines with syntax problems in this code
# Rewrite the code so it displays the following  
# The date is December, 21, 2023

month = 'December'
day = 21
year = 2023
date = f"{month}, {day}, {year}"
message = f"The date is {date}"
print(message)

