# fix01
# This string generates an error when you run the code.
# What can you do with the quotes to fix it?

message = "One of Python's strengths is its diverse community"
print (message)
