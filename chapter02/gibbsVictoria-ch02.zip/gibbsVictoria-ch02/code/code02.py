# code02.py
# Write a short program that uses multiple variable assignments that
# are all on one line. 
# User these variable names: name, age, height
# height should be an integer value representing inches
# Next print out the variable names. Here is an example 

# name, age, height = "Billy", 60, 22
# print(f"{name} is {age} years old and is {height} inches tall")

name, age, height = "Victoria", 38, 70
print(f"{name} is {age} years old and is {height} inches tall")
