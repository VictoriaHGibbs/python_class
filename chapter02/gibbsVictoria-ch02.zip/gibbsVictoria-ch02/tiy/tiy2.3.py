name = 'Victoria'
message = f'Hello {name}, would you like to learn some Python today?'
print(message)
