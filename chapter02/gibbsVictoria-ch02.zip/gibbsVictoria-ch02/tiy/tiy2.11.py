
# stolen from tiy2.10.py
favorite_number = 3
message = f'My favorite number is {favorite_number}'
print(message)

# stolen from tiy2.9.py
print(4+4)
print(10-2)
print(16/2)
print(4*2)
