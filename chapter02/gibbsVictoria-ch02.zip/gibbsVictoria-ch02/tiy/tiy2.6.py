famous_person = 'Stephen King'
message = f'{famous_person} once said “Get busy living or get busy dying.”'
print(message)
