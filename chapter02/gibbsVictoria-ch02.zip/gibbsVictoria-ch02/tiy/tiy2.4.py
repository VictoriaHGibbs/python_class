first_name = 'victoria'
last_name = 'gibbs'

print(first_name.upper())
print(first_name.lower())
print(first_name.title())
