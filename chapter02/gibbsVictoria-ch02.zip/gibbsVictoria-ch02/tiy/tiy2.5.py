print('Stephen King once said “Get busy living or get busy dying.”')
