filename = 'python_notes.txt'

print(filename.removesuffix('.txt'))
