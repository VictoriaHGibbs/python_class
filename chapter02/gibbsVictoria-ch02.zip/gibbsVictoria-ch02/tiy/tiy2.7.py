first_name = '   \n Victoria  \n\t'

print(first_name)
print(first_name.strip())
print(first_name.lstrip())
print(first_name.rstrip())
