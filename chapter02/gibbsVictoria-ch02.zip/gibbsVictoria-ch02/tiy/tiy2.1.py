message = 'my favorite color is blue!'
print(message)
