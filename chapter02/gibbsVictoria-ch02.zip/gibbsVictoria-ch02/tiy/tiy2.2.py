message = 'Dogs are the best animals!'
print(message)

message = 'Cats are awesome as well!'
print(message)
