favorite_number = 3
message = f'My favorite number is {favorite_number}'
print(message)
